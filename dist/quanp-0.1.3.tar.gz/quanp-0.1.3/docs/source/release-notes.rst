Release Notes
=============

.. role:: small
.. role:: smaller

.. note::

   Also see the release notes of :mod:`anndata`.

.. include:: _links.rst
.. include:: _key_contributors.rst



Version 0.1
-----------

0.1.0 :small:`2017-05-17`
~~~~~~~~~~~~~~~~~~~~~~~~~

Quanpy computationally performs and allows quantitative analytics in python.
