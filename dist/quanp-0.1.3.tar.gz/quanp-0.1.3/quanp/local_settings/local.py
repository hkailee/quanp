# settings/local.py

DEBUG = True

TOS_API_KEY = 'IPVNKJZGPDE5VINELGX3PCA6GWAJDX40'

DATA_DIR = '/Users/leehongkai/OneDrive/Finance/quanp/Data'
