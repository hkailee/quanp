"""User settings.
"""
from .local import (
    TOS_API_KEY,
    DEBUG,
)
