from ._anndata import scatter, violin, ranking, clustermap, tracksplot, dendrogram, correlation_matrix, heatmap
from ._dotplot import DotPlot, dotplot
from ._matrixplot import MatrixPlot, matrixplot
from ._stacked_violin import StackedViolin, stacked_violin
from ._preprocessing import filter_features_dispersion, highly_variable_features

from ._tools.scatterplots import embedding, pca, diffmap, draw_graph, tsne, umap, spatial
from ._tools import pca_loadings, pca_scatter, pca_overview, pca_variance_ratio
from ._tools.paga import paga, paga_adjacency, paga_compare, paga_path
from ._tools import dpt_timeseries, dpt_groups_pseudotime
from ._tools import rank_features_groups, rank_features_groups_violin
from ._tools import rank_features_groups_dotplot, rank_features_groups_heatmap, rank_features_groups_stacked_violin, rank_features_groups_matrixplot, rank_features_groups_tracksplot
from ._tools import sim
from ._tools import embedding_density

from ._rcmod import set_rcParams_quanp, set_rcParams_defaults
from . import palettes

from ._utils import matrix
from ._utils import timeseries, timeseries_subplot, timeseries_as_heatmap

from ._qc import highest_expr_features


__doc__ = """\
Plotting API
============

.. currentmodule:: quanp

.. note::
   See the :ref:`settings` section for all important plotting configurations.

.. _pl-generic:

Generic
-------

.. autosummary::
   :toctree: .

   pl.scatter
   pl.heatmap
   pl.dotplot
   pl.tracksplot
   pl.violin
   pl.stacked_violin
   pl.matrixplot
   pl.clustermap
   pl.ranking
   pl.dendrogram


Classes
-------

These classes allow fine tuning of visual parameters. 

.. autosummary::
   :toctree: .

    pl.DotPlot
    pl.MatrixPlot
    pl.StackedViolin


Preprocessing
-------------

Methods for visualizing quality control and results of preprocessing functions.

.. autosummary::
   :toctree: .

   pl.highest_expr_features
   pl.filter_features_dispersion
   pl.highly_variable_features


Tools
-----

Methods that extract and visualize tool-specific annotation in an
:class:`~anndata.AnnData` object.  For any method in module ``tl``, there is
a method with the same name in ``pl``.

PCA
~~~
.. autosummary::
   :toctree: .

   pl.pca
   pl.pca_loadings
   pl.pca_variance_ratio
   pl.pca_overview

Embeddings
~~~~~~~~~~
.. autosummary::
   :toctree: .

   pl.tsne
   pl.umap
   pl.diffmap
   pl.draw_graph
   pl.spatial
   pl.embedding

Compute densities on embeddings.

.. autosummary::
   :toctree: .

   pl.embedding_density

Branching trajectories and pseudotime, clustering
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Visualize clusters using one of the embedding methods passing ``color='louvain'``.

.. autosummary::
   :toctree: .

   pl.dpt_groups_pseudotime
   pl.dpt_timeseries
   pl.paga
   pl.paga_path
   pl.paga_compare

Important features
~~~~~~~~~~~~
.. autosummary::
   :toctree: .

   pl.rank_features_groups
   pl.rank_features_groups_violin
   pl.rank_features_groups_stacked_violin
   pl.rank_features_groups_heatmap
   pl.rank_features_groups_dotplot
   pl.rank_features_groups_matrixplot
   pl.rank_features_groups_tracksplot

Simulations
~~~~~~~~~~~
.. autosummary::
   :toctree: .

   pl.sim
"""
